

<?php $__env->startSection('content'); ?>
    <div class="body-content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="fs-17 font-weight-600 mb-0">Student List</h6>
                            </div>
                            <div class="text-right">
                                <div class="actions">
                                    <a href="#" class="btn btn-success">Add New</a>
                                </div>
                            </div>
                        </div>
                        <h6 class="text-center text-success"><?php echo e(Session::get('msg')); ?></h6>
                    </div>
                    <div class="card-body">
                        <div class=table-responsive>
                            <!--<table class="table table-sm table-nowrap card-table">-->
                            <table class="table display table-bordered table-striped table-hover bg-white m-0 card-table">
                                <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Image</th>
                                    <th>Mobile</th>
                                    <th>Total Amount</th>
                                    <th>Paid Amount</th>
                                    <th>Counsellor</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php ($i=1); ?>
                                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($result->student_name); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset($result->image_path.$result->image)); ?>" alt="" height="100" width="100">
                                        </td>
                                        <td><?php echo e($result->mobile_number); ?></td>
                                        <td><?php echo e($result->total_amount); ?></td>
                                        <td><?php echo e($result->paid_amount); ?></td>
                                        <td><?php echo e($result->counsellor_name); ?></td>
                                        <td>
                                            <a href="#" class="btn btn-success-soft btn-sm mr-1"><i class="far fa-eye"></i></a>
                                            <a href="<?php echo e(route('counsellor.student.edit',$result->id)); ?>" class="btn btn-info-soft btn-sm mr-1"><i class="far fa-edit"></i></a>
                                            <button type="button" class="btn btn-danger-soft btn-sm" onclick="deleteTag(<?php echo e($result->id); ?>)"><i class="far fa-trash-alt"></i></button>
                                            <form id="delete-form-<?php echo e($result->id); ?>" action="<?php echo e(route('counsellor.student.destroy',$result->id)); ?>" method="post" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <script src="https://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.10.12/dist/sweetalert2.all.min.js"></script>

    <script !src="">
        function deleteTag(id) {
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
            })

            swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    event.preventDefault();
                    document.getElementById('delete-form-'+id).submit();
                } else if (
                    /* Read more about handling dismissals below */
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    swalWithBootstrapButtons.fire(
                        'Cancelled',
                        'Your data is safe :)',
                        'error'
                    )
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('counsellor.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel8_student_auth\resources\views/indexx.blade.php ENDPATH**/ ?>