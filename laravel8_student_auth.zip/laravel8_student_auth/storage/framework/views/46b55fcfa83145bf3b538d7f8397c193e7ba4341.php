<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
    <<div class="container">
        <div class="card">
            <div class="card-header d-sm-flex align-items-center justify-content-between">
                <h4>all student</h4>
                <a href="<?php echo e(route('adddata')); ?>" class="btn btn-sm btn-info" >Create</a>
            </div>
            <div class="card-body">
              <form action="<?php echo e(route('adddata')); ?>"method="post" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
              <label for="name">Your Name:</label>
              <input type="text" name="name" id="name"placeholder="your name"><br><br>
              <label for="email">Your Email:</label>
              <input type="email" name="email" id="email"placeholder="your Email"><br><br>

              <label for="number">Your Number:</label>
              <input type="text" name="number" id="number"placeholder="your number"><br><br>


              <label for="file">Your picture:</label>
              <input type="file" name="image" id="file"placeholder="your photo"><br><br>


              <input type="radio" id="male" name="gender" value="male">
               <label for="male">Male</label><br>
               <input type="radio" id="female" name="gender" value="female">
                <label for="female">Female</label><br>

              <label for="cars">Choose a car:</label>

              <select name="cars" id="cars" multiple>
                <option value="volvo">Volvo</option>
                <option value="saab">Saab</option>
                <option value="opel">Opel</option>
                <option value="audi">Audi</option>
              </select>
               
                <button class="btn btn-success"type="submit">Submit</button>







              </form>
            </div>
        </div>
    </div>

    


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>

  </body>
</html><?php /**PATH E:\laravel8_student_auth\resources\views/addmember.blade.php ENDPATH**/ ?>