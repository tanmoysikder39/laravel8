
<?php $__env->startSection('title'); ?>
    <?php echo e('student Details'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header d-sm-flex align-items-center justify-content-between">
            <h4>all student</h4>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-sm btn-info" >All Student</a>
        </div>
        <div class="card-body">
            <?php if(Session::has('message')): ?>
            <div class="alert alert-success">
            <strong><?php echo e(Session::get('message')); ?></strong>
             </div>
            <?php endif; ?>
            <p class="font-weight-bold"> Name:</p>
            <p><?php echo e($student->name); ?></p>

            <p class="font-weight-bold">Email:</p>
            <p><?php echo e($student->email); ?></p>
      
            <p class="font-weight-bold">Number:</p>
            <p><?php echo e($student->number); ?></p>
      
            <p class="font-weight-bold">File:</p>
            <p><?php echo e($student->file); ?></p>

            <p class="font-weight-bold">Gender:</p>
            <p><?php echo e($student->gender); ?></p>

            <p class="font-weight-bold">cars:</p>
            <p><?php echo e($student->option); ?></p>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel8_student_auth\resources\views/show2.blade.php ENDPATH**/ ?>