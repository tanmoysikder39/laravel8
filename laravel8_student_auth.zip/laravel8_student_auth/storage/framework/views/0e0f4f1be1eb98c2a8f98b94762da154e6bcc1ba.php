
<?php $__env->startSection('title'); ?>
    <?php echo e(' Student Details'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header d-sm-flex align-items-center justify-content-between">
            <h4>student Details</h4>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-sm btn-info" >All student</a>
        </div>
        <div class="card-body">
            <?php if(Session::has('message')): ?>
            <div class="alert alert-success m-auto text-center">
            <strong><?php echo e(Session::get('message')); ?></strong>
             </div>
            <?php endif; ?>
          <p class="font-weight-bold" >Name:</p><br>
          <p><?php echo e($student->name); ?></p><br><br>

          <p class="font-weight-bold" >Email:</p><br>
          <p><?php echo e($student->email); ?></p><br><br>


          <p class="font-weight-bold" >Name:</p><br>
          <p><?php echo e($student->number); ?></p><br><br>


          <p class="font-weight-bold" >Image:</p><br>
          <p><?php echo e($student->file); ?></p><br><br>


          <p class="font-weight-bold" >Gender:</p><br>
          <p><?php echo e($student->gender); ?></p><br><br>

          <p class="font-weight-bold" >option:</p><br>
          <p><?php echo e($student->option); ?></p><br><br>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel8_student_auth\resources\views/show.blade.php ENDPATH**/ ?>