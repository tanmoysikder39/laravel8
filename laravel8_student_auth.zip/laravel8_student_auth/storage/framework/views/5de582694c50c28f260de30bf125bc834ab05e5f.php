
<?php $__env->startSection('title'); ?>
    <?php echo e('All Student'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header d-sm-flex align-items-center justify-content-between">
            <h4>all student</h4>
            <a href="<?php echo e(url('create')); ?>" class="btn btn-sm btn-info" >Create</a>
        </div>
        <div class="card-body">
            <?php if(Session::has('message')): ?>
            <div class="alert alert-success">
            <strong><?php echo e(Session::get('message')); ?></strong>
             </div>
            <?php endif; ?>
           
            <table class="table table-bordered">
                <tbody>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Number</th>
                        <th>File</th>
                        <th>Gender</th>
                        <th>option</th>
                        <th>usese</th>
                        
                    </tr>
                 </thead>
                 <tbody>
                     <?php $__currentLoopData = $singledata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e(++$loop->index); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->number); ?></td>
                        <td><?php echo e($item->image); ?></td>
                        <td><?php echo e($item->gender); ?></td>
                        <td><?php echo e($item->option); ?></td>
                       
                      
                        <td>
                            <a href=""class="btn btn-sm btn-secondary">View</a>
                            <a href="<?php echo e(url('edit',$item->id)); ?>"class="btn btn-sm btn-primary">Edit</a>
                            <form action="<?php echo e(route('delete',$item->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="btn btn-sm btn-danger">Delete</button>
                            </form>
                         
                           
                            
                        </td>
                    </tr> 
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tbody>
            </table>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel8_student_auth\resources\views/list.blade.php ENDPATH**/ ?>