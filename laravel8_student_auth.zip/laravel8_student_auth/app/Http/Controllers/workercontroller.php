<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class workercontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user=DB::table('workers')->get();
        return view('index',['worker'=>$user]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       return view('create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|max:255',
            'email' => 'required|unique:workers',
            'number' => 'required|string|min:10|unique:workers',
            'image'=>'required',
            'gender'=>'required|string|',
            'cars'=>'required|string|'
        ]);
        
    DB::table('workers')->insert([
        'name'=>$request->name,
        'email'=>$request->email,
        'number'=>$request->number,
        'file'=>$request->image,
        'gender'=>$request->gender,
        'option'=>$request->cars,
    ]);
    $request->session()->flash('message','student id created');
    return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user=DB::table('workers')->find($id);
        return view('show',['student'=>$user]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user=DB::table('workers')->find($id);
        return view('edit',['student'=>$user]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'name' => 'required|max:255',
            'email' => 'required|unique:workers,email,'.$id,
            'number' => 'required|string|min:10|unique:workers,number,'.$id,
            'image'=>'required',
            'gender'=>'required|string|',
            'cars'=>'required|string|'
        ]);
        
    DB::table('workers')->where('id',$id)->update([
        'name'=>$request->name,
        'email'=>$request->email,
        'number'=>$request->number,
        'file'=>$request->image,
        'gender'=>$request->gender,
        'option'=>$request->cars,
    ]);
    $request->session()->flash('message','student id updated');
    return redirect()->back();
    }
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
       DB::table('workers')->where('id',$id)->delete();
       $request->session()->flash('message','student id Deleted');
       return redirect()->back();
    }
}
